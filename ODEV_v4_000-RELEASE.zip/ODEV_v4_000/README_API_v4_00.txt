File provided with the API v4.00:
==========================================

Oriel Computer Interfacing v4_00.pdf - User manual for API usage

API_DLLs_v4_00.zip - a DLL folder with all the header files and DLL files and a subfolder with the LIB files for C++ linking.  .NET can also use these files if the programmer has experience calling unmanaged C++ DLLs.

ODEV_Sample_Cpp_v4_00.zip - a Full Visual Studio 2013 solution using the provided API.  How to arrange using it in a project and sample code is provided here.  The project is a C++ MFC Simple Application.  It will autodiscover a connected device and allow for sending commands and queries to it.

ODevice_LabVIEW2014_v4_00.zip - a LabVIEW project that makes use of the API.  It is based on a communication object that is initialized and manages commmunication for you.  So you an drop this object vi in your code and select the action you want it to perform (Open, Write, Close, etc.)  This sample can preform a scan over a range of wavelengths with any of the supported monochromotors.  (There is a vi used in the sample that will create the correct string based on the different command sets for the instruments for some of the popular commands.  This allows for a single application that support multiple command sets.)

README_API_v4_00.txt - This file.